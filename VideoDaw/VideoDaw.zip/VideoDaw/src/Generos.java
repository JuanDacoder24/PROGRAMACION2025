public enum Generos {
    Drama, Comedia, Terror, Accion, Ficcion, Fantasia
}
