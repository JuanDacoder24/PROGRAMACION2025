public abstract class Astros {
    
    protected double radioEcuatorial;
    protected double rotacionSobreEje;
    protected double masa;
    protected double temperatura;
    protected double gravedad;
    
    public double getRadioEcuatorial() {
        return radioEcuatorial;
    }
    public double getRotacionSobreEje() {
        return rotacionSobreEje;
    }
    public double getMasa() {
        return masa;
    }
    public double getTemperatura() {
        return temperatura;
    }
    public double getGravedad() {
        return gravedad;
    }


}
